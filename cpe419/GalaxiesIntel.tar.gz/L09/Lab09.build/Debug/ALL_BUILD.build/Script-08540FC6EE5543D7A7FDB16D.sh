#!/bin/sh
make -C /Users/imeeder/Classwork/CPE474/Labs/L09 -f /Users/imeeder/Classwork/CPE474/Labs/L09/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
