#ifndef PLAYERS_H
#define PLAYERS_H

/* TODO: Change userid, below, to your ACTUAL CalPoly userid. For example,
 *       I would change it to:
 *
 *          extern PlayerFuncs kmammen().
 */
extern PlayerFuncs userid();

/* TODO: Change userid, below, to your ACTUAL CalPoly userid. For example,
 *       I would change it to: 
 *
 *          static FuncGetPlayerFuncs players[] =
 *          {
 *             kmammen
 *          };
 */
static FuncGetPlayerFuncs players[] =
{
   userid 
};

#endif
